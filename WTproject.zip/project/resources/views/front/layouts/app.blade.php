<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
  <meta name="generator" content="Jekyll v3.8.5">
  <title>Ebook Archive</title>

  @include('front.layouts.partials.style')

</head>
<body>

@include('front.layouts.partials.header')
@yields('content')
@include('front.layouts.partials.footer')
@include('front.layouts.partials.script')
</body>
</html>
