
<div class="footer-area">
  <div class="container">
    <div class="row">
      
      <div class="col-md-3">
        <img src="{{ asset('images/logo.png') }}" class="logo-image">
        <p>
          <address>
           Ebook & Audiobook Archive
            <br>
            /WT Project
            <br>
            by Fabiha,Prothoma,Mohotina,Lamisa
          </address>
        </p>
      </div>

      <div class="col-md-3">
        <h4>Top Links</h4>
        <ul>
          <li><a href="">Home</a></li>
          <li><a href="">Login</a></li>
          <li><a href="">Create New Account</a></li>
          <li><a href="">Privacy Policy</a></li>
        </ul>
      </div>


      <div class="col-md-3">
        <h4>Top Links</h4>
        <ul>
          <li><a href="">Home</a></li>
          <li><a href="">Login</a></li>
          <li><a href="">Create New Account</a></li>
          <li><a href="">Privacy Policy</a></li>
        </ul>
      </div>


      <div class="col-md-3">
        <h4>Top Links</h4>
        <ul>
          <li><a href="">Home</a></li>
          <li><a href="">Login</a></li>
          <li><a href="">Create New Account</a></li>
          <li><a href="">Privacy Policy</a></li>
        </ul>
      </div>

    </div>

  </div>
</div>
